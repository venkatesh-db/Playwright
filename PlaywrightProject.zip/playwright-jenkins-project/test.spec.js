
const { test, expect } = require('@playwright/test');

test('Example Domain Test', async ({ page }) => {
  // Go to a website
  await page.goto('https://example.com');
  
  // Get the title of the page
  const title = await page.title();

  // Assert the title is correct
  expect(title).toBe('Example Domain');
});
