
const { chromium } = require('playwright');

(async () => {
  // Launch browser in non-headless mode (will show the browser)
  const browser = await chromium.launch({ headless: false });
  const page = await browser.newPage();
  
  // Navigate to a website
  await page.goto('https://example.com');
  
  // Take a screenshot
  await page.screenshot({ path: 'example.png' });
  
  // Close the browser
  await browser.close();
})();
