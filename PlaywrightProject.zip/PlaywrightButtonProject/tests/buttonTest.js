
// tests/buttonTest.js

const { chromium } = require('playwright');
const HomePage = require('../pages/home');
const AboutPage = require('../pages/about');

(async () => {
  // Launch the browser
  const browser = await chromium.launch({ headless: false }); // Set to false to see the browser
  const page = await browser.newPage();
  
  // Go to the home page with a button
  await page.goto('data:text/html,<html><body><h1>Home Page</h1><button id="navigateButton">Go to About Page</button></body></html>');
  
  // Instantiate the HomePage class
  const homePage = new HomePage(page);
  
  // Click the button to go to the About page
  await homePage.goToAboutPage();
  
  // Simulate the About page content (you can replace this with real URL or actual content)
  await page.goto('data:text/html,<html><body><h1>About Page</h1><p>Welcome to the About Page!</p></body></html>');
  
  // Instantiate the AboutPage class
  const aboutPage = new AboutPage(page);
  
  // Verify we're on the About page
  await aboutPage.checkText();

  // Close the browser
  await browser.close();
})();
