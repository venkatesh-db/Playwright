

// pages/home.js

class HomePage {
  constructor(page) {
    this.page = page;
    this.button = page.locator('#navigateButton'); // Locator for the button
  }

  async goToAboutPage() {
    await this.button.click(); // Click the button
  }
}

module.exports = HomePage;
