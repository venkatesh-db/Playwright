
// pages/about.js

class AboutPage {
  constructor(page) {
    this.page = page;
  }

  async checkText() {
    const text = await this.page.locator('h1').textContent();
    console.log(text); // Log the header text to confirm we're on the correct page
  }
}

module.exports = AboutPage;
