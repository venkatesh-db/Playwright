
// tests/locators-actions.spec.js
const { test, expect } = require('@playwright/test');


// Helper: log to console with a prefix so it’s easy to spot in the report
function log(label, value) {
console.log(`[DEMO] ${label}:`, value);
}


// 1) LOCATORS: getByText / getByRole / getByLabel / locator()
// Using a TryIt page with an iframe (consistent, has labels and a submit button)
// https://www.w3schools.com/html/tryit.asp?filename=tryhtml_input_text


test('Playwright locators basics', async ({ page }) => {
await page.goto('https://www.w3schools.com/html/tryit.asp?filename=tryhtml_input_text');
const frame = page.frameLocator('#iframeResult');


// getByText – locate static text
await expect(frame.getByText(/First name/i)).toBeVisible();


// getByLabel – target by the <label> text
await frame.getByLabel(/First name/i).fill('Venkatesh');
await frame.getByLabel(/Last name/i).fill('Coder');


// getByRole – the Submit input has role=button
await expect(frame.getByRole('button', { name: /submit/i })).toBeVisible();


// locator() / page.locator() – CSS selectors
await frame.locator('input[name="fname"]').fill('Venky');
await frame.locator('input[name="lname"]').fill('Playwright');


// Click submit to show we can interact; page will navigate but that’s fine for demo
await frame.getByRole('button', { name: /submit/i }).click();
});


// 2) CSS SELECTORS: Tag, ID, Class, Attribute
// We’ll use the same TryIt page for consistency


test('CSS selectors: tag, id, class, attribute', async ({ page }) => {
await page.goto('https://www.w3schools.com/html/tryit.asp?filename=tryhtml_input_text');
const frame = page.frameLocator('#iframeResult');


// Tag selector (applies to all <input> elements)
await frame.locator('input').first().fill('Tag selector');


// Attribute selector – highly reliable
await frame.locator('input[name="fname"]').fill('By attribute');
await frame.locator('input[name="lname"]').fill('Selector');


});