
import { test, expect } from '@playwright/test';

test('Intercept GraphQL query in UI', async ({ page }) => {
  await page.route('**/graphql', async (route) => {
    const request = route.request();
    const postData = request.postDataJSON();
    console.log('Intercepted GraphQL query:', postData.query);
    console.log('Variables:', postData.variables);

    // mock a response
    if (postData.query.includes('GetCountry')) {
      return route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          data: { country: { code: 'ZZ', name: 'Mockland', continent: { name: 'Nowhere' }, languages: [] } },
        }),
      });
    }

    await route.continue();
  });

  // navigate to a demo app that calls GraphQL
  await page.goto('https://countries.trevorblades.com'); // has GraphQL playground
  expect(await page.title()).toContain('GraphQL');
});
