
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: 'html',
  use: {
    trace: 'on-first-retry',
  },
});
