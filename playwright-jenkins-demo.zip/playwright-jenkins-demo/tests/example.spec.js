

// tests/example.spec.js
const { test, expect } = require('@playwright/test');

test('Google search works', async ({ page }) => {
  await page.goto('https://www.google.com');
  await page.fill('textarea[name="q"]', 'Playwright');
  await page.keyboard.press('Enter');
  await page.waitForTimeout(2000);
  const title = await page.title();
  expect(title).toContain('Playwright');
});
