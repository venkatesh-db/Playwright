
// playwright.config.js
const { defineConfig } = require('@playwright/test');

module.exports = defineConfig({
  testDir: './tests',   // directory where your tests live
  timeout: 30 * 1000,   // 30s per test
  reporter: [
    ['list'],
    ['junit', { outputFile: 'test-results.xml' }],
    ['html', { outputFolder: 'playwright-report', open: 'never' }]
  ],
  use: {
    headless: true,
    screenshot: 'only-on-failure',
    video: 'retain-on-failure'
  }
});
