
// tests/api.spec.ts
import { test, expect, request, APIRequestContext } from '@playwright/test';

const BASE_URL = 'https://reqres.in'; // or replace with your actual API
let api: APIRequestContext;

test.describe('REST API with Playwright', () => {
  test.beforeAll(async () => {
    // 👇 set up headers with API key
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      // Use your API key here (either env var or hardcoded)
      'x-api-key': process.env.API_KEY || 'PUT_YOUR_API_KEY_HERE',
      // If your API instead expects Bearer tokens, use this instead:
      // 'Authorization': `Bearer ${process.env.API_KEY || 'PUT_YOUR_API_KEY_HERE'}`
    };

    api = await request.newContext({
      baseURL: BASE_URL,
      extraHTTPHeaders: headers,
    });
  });

  test.afterAll(async () => {
    await api.dispose();
  });

  test('GET: list users (page=2)', async () => {
    const res = await api.get('/api/users', { params: { page: 2 } });
    console.log('GET status:', res.status(), 'body:', await res.text());
    expect(res.ok()).toBeTruthy();
    expect(res.status()).toBe(200);
  });

  test('POST: create user with JSON', async () => {
    const payload = { name: 'morpheus', job: 'leader' };
    const res = await api.post('/api/users', { data: payload });
    console.log('POST status:', res.status(), 'body:', await res.text());
    expect(res.ok()).toBeTruthy();
    expect(res.status()).toBe(201);
  });

  test('PUT: update user', async () => {
    const payload = { name: 'morpheus', job: 'zion resident' };
    const res = await api.put('/api/users/2', { data: payload });
    console.log('PUT status:', res.status(), 'body:', await res.text());
    expect(res.ok()).toBeTruthy();
    expect(res.status()).toBe(200);
  });

  test('DELETE: delete user', async () => {
    const res = await api.delete('/api/users/2');
    console.log('DELETE status:', res.status(), 'body:', await res.text());
    expect(res.status()).toBe(204);
  });

  test('Negative: login fails without password', async () => {
    const res = await api.post('/api/login', {
      data: { email: 'eve.holt@reqres.in' },
      failOnStatusCode: false,
    });
    console.log('Negative login status:', res.status(), 'body:', await res.text());
    expect(res.status()).toBe(400);
  });
});
